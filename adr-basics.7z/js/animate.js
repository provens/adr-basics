function reload() {
  
  location.reload(true);
}